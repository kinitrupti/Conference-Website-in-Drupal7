# Run Unish, the test suite for Drush.
vendor/bin/phpunit --configuration tests $@
